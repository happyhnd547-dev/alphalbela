from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from models import User
from auth import register_user, verify_user

app = FastAPI()

# Allow frontend (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For dev; restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/register")
def register(user: User):
    if register_user(user.username, user.password):
        return {"message": "User registered successfully"}
    raise HTTPException(status_code=400, detail="Username already exists")

@app.post("/login")
def login(user: User):
    if verify_user(user.username, user.password):
        return {"message": "Login successful"}
    raise HTTPException(status_code=401, detail="Invalid username or password")