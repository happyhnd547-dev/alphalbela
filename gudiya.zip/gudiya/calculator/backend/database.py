# database.py

import sqlite3

def create_users_table():
    conn = sqlite3.connect("users.db")  # This creates users.db
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

# Call the function to create the DB & table
create_users_table()